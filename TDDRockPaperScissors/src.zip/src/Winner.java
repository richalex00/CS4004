
public class Winner {

}
